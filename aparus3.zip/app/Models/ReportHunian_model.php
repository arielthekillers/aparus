<?php

namespace App\Models;

use CodeIgniter\Model;

class ReportHunian_model extends Model
{
    protected $table      = 'kontrak';
    protected $primaryKey = 'kontrak_id';
    protected $allowedFields = ['status_kontrak', 'nomor_kontrak', 'penghuni', 'kamar', 'tgl_awal_kontrak', 'tgl_akhir_kontrak'];

    public function getPenghuni($rusun = null)
    {
        $builder = $this->db->table('kontrak');
        $builder->select('count(kontrak_id) as jumlah');
        $builder->join('penghuni', 'kontrak.penghuni = penghuni.kode_penghuni', 'LEFT');
        $builder->groupBy('kontrak_id');
        return $builder->get();
    }




















    public function countAduan()
    {
        $builder = $this->db->table('aduan');
        $builder->select('status,count(status) as jumlahperstatus');
        if (session('usertype') == 'penghuni') {
            $builder->where('aduan.pengadu', session('userid'));
        }
        $builder->groupBy('status');
        $builder->orderBy('status', 'DESC');
        return $builder->get();
    }
    public function countAllAduan()
    {
        $builder = $this->db->table('aduan');
        $builder->select('status,count(status) as jumlah');
        if (session('usertype') == 'penghuni') {
            $builder->where('aduan.pengadu', session('userid'));
        }
        return $builder->countAllResults();
    }

    public function getAduanWithUserToday()
    {
        $builder = $this->db->query('SELECT `judul`, `deskripsi`, `pengadu`, `hunian`, `aprs_aduan`.`status` as sstatus,`teknisi`, `ktp`, `nama`, `kode_penghuni`, `kontak`, `aprs_aduan`.`created_at` as tgladuan FROM `aprs_aduan` LEFT JOIN `aprs_penghuni` ON `kode_penghuni` = `pengadu` WHERE date(aprs_aduan.created_at) = CURDATE() ORDER BY aprs_aduan.created_at DESC');
        return $builder;
    }

    public function countAduanWithUserToday()
    {
        $builder = $this->db->query('SELECT `status` , count(id_aduan) as jumlahperstatus from aprs_aduan WHERE date(aprs_aduan.created_at) = CURDATE() GROUP BY `status`');
        return $builder;
    }
}
