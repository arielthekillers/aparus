<?= $this->include('partials/main') ?>

<head>

    <?php echo view('partials/title-meta', array('title' => 'Daftar Menunggu')); ?>
    <!-- glightbox css -->
    <link rel="stylesheet" href="/assets/libs/glightbox/css/glightbox.min.css">

    <?= $this->include('partials/head-css') ?>

</head>

<body>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <?= $this->include('partials/menu') ?>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <div class="row">

                        <?php
                        $i = 1;
                        $colors = array("success", "danger", "primary", "secondary", "warning", "info", "dark");
                        shuffle($colors);
                        ?>
                        <?php foreach ($daftarrusun as $s) : ?>
                            <div class="col-lg-3 col-md-6">
                                <div class="card card-animate overflow-hidden">
                                    <div class="position-absolute start-0" style="z-index: 0;">
                                        <svg version="1.2" xmlns="http://www.w3.org/2000/svg" width="175" height="200" viewBox="20 20 200 140">
                                            <style>
                                                .s<?= $i; ?> {
                                                    opacity: .10;
                                                    fill: var(--vz-<?= array_shift($colors); ?>)
                                                }
                                            </style>
                                            <path id="Shape 8" class="s<?= $i; ?>" d="m189.5-25.8c0 0 20.1 46.2-26.7 71.4 0 0-60 15.4-62.3 65.3-2.2 49.8-50.6 59.3-57.8 61.5-7.2 2.3-60.8 0-60.8 0l-11.9-199.4z" />
                                        </svg>
                                    </div>
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between">
                                            <div>
                                                <p class="fw-medium text-muted mb-0">Daftar Tunggu</p>
                                                <h4 class="ff-secondary fw-semibold"><a href="<?= site_url('penghuni/daftartunggu/' . strtolower($s['rusun_id'])); ?>"><?= $s['rusun_nama']; ?></a></h4>
                                            </div>
                                        </div>
                                    </div><!-- end card body -->
                                </div> <!-- end card-->
                            </div> <!-- end col-->
                            <?php $i++; ?>
                        <?php endforeach; ?>


                        <div class="col-lg-12">
                            <div class="card" id="tasksList">
                                <div class="card-header bg-primary border-0">
                                    <div class="d-flex align-items-center">
                                        <h5 class="card-title mb-0 flex-grow-1 text-white">Daftar Menunggu <?= (isset($rusun) ? $rusun['rusun_nama'] : ""); ?></h5>
                                    </div>
                                </div>
                                <!--end card-body-->
                                <div class="card-body">
                                    <div class="table-responsive table-card mb-4">
                                        <table class="table align-middle table-nowrap mb-0" id="tasksTable">
                                            <thead class="table-light text-muted">
                                                <tr>
                                                    <th>ID</th>
                                                    <th>No. KTP</th>
                                                    <th>Nama</th>
                                                    <th>Nomor Telepon</th>
                                                    <th>Rusun Tujuan</th>
                                                    <th>Tanggal Pengajuan</th>
                                                    <th>Registrar</th>
                                                    <th>Tindakan</th>
                                                </tr>
                                            </thead>
                                            <tbody class="list">
                                                <?php if (!empty($penghuni)) : ?>
                                                    <?php foreach ($penghuni as $data) : ?>
                                                        <tr>
                                                            <td><a href="<?= site_url('penghuni/edit/' . $data['kode_penghuni']); ?>" class="fw-medium link-primary">#<?= $data['kode_penghuni']; ?></a></td>
                                                            <td><?= $data['ktp']; ?></td>
                                                            <td><?= $data['nama']; ?></td>
                                                            <td><a href="https://wa.me/<?= fixphonenumber($data['kontak']); ?>" target="_blank"><?= $data['kontak']; ?></a></td>
                                                            <td><?= $data['rusun_nama']; ?></td>
                                                            <td><?= timestamp($data['waktudaftar']); ?></td>
                                                            <td>
                                                                <div class="d-flex align-items-center">
                                                                    <div class="flex-shrink-0">
                                                                        <img src="/uploads/profil/<?= $data['avatar']; ?>" alt="" class="avatar-xxs rounded-circle image_src object-fit-cover">
                                                                    </div>
                                                                    <div class="flex-grow-1 ms-2 name"><?= $data['user_nick']; ?></div>
                                                                </div>
                                                            </td>
                                                            <td>
                                                                <?php if ($data['statuspendaftaran'] == "1") : ?>
                                                                    <a href="<?= site_url('penghuni/verifikasi/' . $data['kode_penghuni']); ?>" class="btn btn-sm btn-warning">VERIFIKASI DATA</a>
                                                                <?php elseif ($data['statuspendaftaran'] == "2") : ?>
                                                                    <a href="<?= site_url('kontrak/tambah/' . $data['kode_penghuni']); ?>" class="btn btn-sm btn-success">PROSES KONTRAK</a>
                                                                <?php else : ?>
                                                                    <?= $data['statuspendaftaran']; ?>
                                                                <?php endif; ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                <?php else : ?>
                                                    <tr>
                                                        <td colspan="8" class="text-center">Data belum ada</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                        <!--end table-->
                                    </div>
                                </div>
                                <!--end card-body-->
                            </div>
                            <!--end card-->
                        </div>

                    </div>
                    <!--end row-->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

        </div>
        <?= $this->include('partials/footer') ?>

        <!-- end main content-->
    </div>
    <!-- END layout-wrapper -->

    <script type="text/javascript">
        window.setTimeout(function() {
            $(".alert-message").fadeTo(500, 0).slideUp(500, function() {
                $(this).remove();
            });
        }, 3000);
    </script>


    <?= $this->include('partials/customizer') ?>

    <?= $this->include('partials/vendor-scripts') ?>

    <script src="/assets/js/rupiah.js"></script>



    <!-- App js -->
    <script src="/assets/js/app.js"></script>

</body>