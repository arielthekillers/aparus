<?= $this->include('partials/main') ?>

<head>

    <?php echo view('partials/title-meta', array('title' => 'Daftar Penghuni')); ?>
    <!-- glightbox css -->
    <link rel="stylesheet" href="/assets/libs/glightbox/css/glightbox.min.css">

    <?= $this->include('partials/head-css') ?>

</head>

<body>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <?= $this->include('partials/menu') ?>

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <div class="row">

                        <div class="col-lg-12">
                            <div class="card" id="tasksList">
                                <div class="card-header border-0">
                                    <div class="d-flex align-items-center">
                                        <h5 class="card-title mb-0 flex-grow-1">Daftar Penghuni</h5>
                                        <div class="flex-shrink-0">
                                            <form action="javascript:void(0);">
                                                <div class="row row-cols-lg-auto g-3 align-items-center">
                                                    <div class="col-12">
                                                        <select class="form-select" name="rusun">
                                                            <option selected>Pilih Rusun</option>
                                                            <option value="1">One</option>
                                                            <option value="2">Two</option>
                                                            <option value="3">Three</option>
                                                        </select>
                                                    </div><!--end col-->
                                                    <div class="col-12">
                                                        <select class="form-select" name="lantai">
                                                            <option selected>Pilih Lantai</option>
                                                            <option value="1">One</option>
                                                            <option value="2">Two</option>
                                                            <option value="3">Three</option>
                                                        </select>
                                                    </div><!--end col-->
                                                    <div class="col-12">
                                                        <button type="submit" class="btn btn-primary">Tampilkan Data</button>
                                                    </div><!--end col-->
                                                </div><!--end row-->
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!--end card-body-->
                                <div class="card-body">
                                    <div class="table-responsive table-card mb-4">
                                        <table class="table align-middle table-nowrap mb-0" id="tasksTable">
                                            <thead class="table-light text-muted">
                                                <tr>
                                                    <th>ID</th>
                                                    <th>No. KTP</th>
                                                    <th>Nama</th>
                                                    <th>Hunian</th>
                                                    <th>Nomor Kontrak</th>
                                                    <th>Tanggal Kontrak</th>
                                                    <th>Status</th>
                                                    <th>Priority</th>
                                                </tr>
                                            </thead>
                                            <tbody class="list">
                                                <?php foreach ($penghuni as $data) : ?>
                                                    <tr>
                                                        <td class="id"><a href="<?= site_url('penghuni/edit/' . $data['kode_penghuni']); ?>" class="fw-medium link-primary">#<?= $data['kode_penghuni']; ?></a></td>
                                                        <td class="project_name"><?= $data['ktp']; ?></td>
                                                        <td><?= $data['nama']; ?></td>
                                                        <td class="client_name">Rusun Api Api - Lantai 1 B - Kamar 3</td>
                                                        <td class="id"><a href="apps-tasks-details.html" class="fw-medium link-primary">#<?= $data['kode_penghuni']; ?></a></td>
                                                        <td class="due_date">15 Dec, 2020</td>
                                                        <td class="status"><span class="badge bg-secondary-subtle text-secondary text-uppercase">Inprogress</span></td>
                                                        <td class="priority"><span class="badge bg-warning text-uppercase">Medium</span></td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                        <!--end table-->
                                        <div class="noresult" style="display: none">
                                            <div class="text-center">
                                                <lord-icon src="https://cdn.lordicon.com/msoeawqm.json" trigger="loop" colors="primary:#121331,secondary:#08a88a" style="width:75px;height:75px"></lord-icon>
                                                <h5 class="mt-2">Sorry! No Result Found</h5>
                                                <p class="text-muted mb-0">We've searched more than 200k+ tasks We did not find any tasks for you search.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-end mt-2">
                                        <div class="pagination-wrap hstack gap-2" style="display: flex;">
                                            <a class="page-item pagination-prev disabled" href="#">
                                                Previous
                                            </a>
                                            <ul class="pagination listjs-pagination mb-0">
                                                <li class="active"><a class="page" href="#" data-i="1" data-page="8">1</a></li>
                                                <li><a class="page" href="#" data-i="2" data-page="8">2</a></li>
                                            </ul>
                                            <a class="page-item pagination-next" href="#">
                                                Next
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <!--end card-body-->
                            </div>
                            <!--end card-->
                        </div>

                    </div>
                    <!--end row-->
                </div>
                <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

        </div>
        <?= $this->include('partials/footer') ?>

        <!-- end main content-->
    </div>
    <!-- END layout-wrapper -->

    <script type="text/javascript">
        window.setTimeout(function() {
            $(".alert-message").fadeTo(500, 0).slideUp(500, function() {
                $(this).remove();
            });
        }, 3000);
    </script>


    <?= $this->include('partials/customizer') ?>

    <?= $this->include('partials/vendor-scripts') ?>

    <script src="/assets/js/rupiah.js"></script>



    <!-- App js -->
    <script src="/assets/js/app.js"></script>

</body>